
package parcial1recu;

import java.util.Objects;


public abstract class Robot {
    private String serie;
    private String fabricante;
    private int bateria;
    private int consumo;
    private Prioridad nivelPrioridad;
    public static final int BATERIA_MAX = 100;
    public static final int BATERIA_MIN = 0;
    public static final int ATRIBUTO_MIN = 0;
    
    public Robot(String s, String f, Prioridad p, int bateria){
        Objects.requireNonNull(s);
        Objects.requireNonNull(f);
        if (s.isBlank() || f.isBlank()) {
            throw new IllegalArgumentException("Serie y fabricante no pueden estar vacios");
        }
        if (bateria < BATERIA_MIN || bateria > BATERIA_MAX) {
            throw new IllegalArgumentException("Bateria invalida");
        }
        this.bateria = bateria;
        this.serie = s;
        this.fabricante = f;
        this.nivelPrioridad = p;
        
    }
    
    public String getSerie(){
        return this.serie;
    }
    
    public String getFabricante() {
        return this.fabricante;
    }
    
    public Prioridad getPrioridad() {
        return this.nivelPrioridad;
    }
    
    public int getBateria() {
        return this.bateria;
    }
    
    public int getConsumo() {
        return this.consumo;
    }
    
    @Override
    public boolean equals(Object o){
        boolean equals = false;
        if (o instanceof Robot r) {
            equals = (this.fabricante == r.getFabricante() && this.serie == r.getSerie());
        }
        return equals;
    }
    
    protected void setConsumo(int consumo) {
        this.consumo = consumo;
    }
    
    protected boolean consumirBateria() {
        boolean puedeConsumir = false;
        try {
        if (this.bateria >= this.consumo){
            puedeConsumir = true;
            this.bateria -= this.consumo;
        } else {
            throw new IllegalStateException();
        }
        } catch (IllegalStateException e) {
            System.out.println("El robot " + this.serie + " tiene bateria insuficiente para realizar sus funciones");
        }
        return puedeConsumir;
    }
    protected abstract int calcularConsumo();
}
