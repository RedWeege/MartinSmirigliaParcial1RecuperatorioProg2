package parcial1recu;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class FlotaRobots {
    private String empresa;
    private List<Robot> sistemaRobots;
    
    public FlotaRobots(String e){
        Objects.requireNonNull(e);
        if (e.isBlank()) {
            throw new IllegalArgumentException("Empresa no puede estar en blanco");
        }
        this.empresa = e;
        this.sistemaRobots = new ArrayList<Robot>();
    }
    
    public void agregarRobot(Robot r){
        try {
        if (sistemaRobots.contains(r)) {
            throw new RobotDuplicadoException();
        } else {
            sistemaRobots.add(r);
        } } catch (RobotDuplicadoException e) {
            System.out.println("No se pudo agregar: Ya existe un robot con serie " + r.getSerie() + " y fabricante " + r.getFabricante());
        }
    }
    
    public List<Robot> obtenerRobots() {
        return this.sistemaRobots;
    }
    
    public ArrayList<Robot> filtrarPorPrioridad(Prioridad p) {
        ArrayList<Robot> lista = new ArrayList<>();
        for (int i = 0; i < this.sistemaRobots.size() ; i++) {
            if (sistemaRobots.get(i).getPrioridad() == p) {
                lista.add(sistemaRobots.get(i));
            }
        }
        return lista;
    }
    
    public ArrayList<Robot> filtrarPorConsumo(int c) {
        ArrayList<Robot> lista = new ArrayList<>();
        for (int i = 0; i < this.sistemaRobots.size() ; i++) {
            if (sistemaRobots.get(i).getConsumo() <= c) {
                lista.add(sistemaRobots.get(i));
            }
        }
        return lista;
    }
    
    public String getEmpresa() {
        return this.empresa;
    }
}
