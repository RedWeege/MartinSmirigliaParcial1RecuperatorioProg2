
package parcial1recu;


public interface Diagnosticable {
    
    public void diagnosticar();
}
