package parcial1recu;

public class RobotReparto extends Robot implements Ejecutable, Diagnosticable{
    private int capacidad;
    public static final int MODIFICADOR_CONSUMO_1 = 3;
    public static final int MODIFICADOR_CONSUMO_2 = 4;
    
    public RobotReparto(String s, String f, Prioridad p, int bateria, int capacidad) {
        super(s, f, p, bateria);
        if (capacidad < super.ATRIBUTO_MIN) {
            throw new IllegalArgumentException();
        }
        this.capacidad = capacidad;
        setConsumo(calcularConsumo());
    }
    @Override
    protected int calcularConsumo() {
        return this.capacidad * MODIFICADOR_CONSUMO_1 + MODIFICADOR_CONSUMO_2;
    }
    
    @Override
    public void ejecutar() {
        if (consumirBateria()) {
            System.out.println("Servicio de Entregua " + this.getSerie() + " ejecutado. Bateria restante: " + this.getBateria() + "%");
        }
    }
        
    @Override
    public void diagnosticar() {
        System.out.println("Robot de Reparto " + this.getSerie() + ". Capacidad: " + this.capacidad +"KG");
    }
    
    public int getCapacidad() {
        return this.capacidad;
    }
    
    public String toString() {
        return this.getClass() + " [serie=" + this.getSerie() + ", fabricante=" + this.getFabricante() +", prioridad=" + this.getPrioridad() +", bateria=" +this.getBateria()+", capacidad=" + this.getCapacidad() + "]";
    }
}
