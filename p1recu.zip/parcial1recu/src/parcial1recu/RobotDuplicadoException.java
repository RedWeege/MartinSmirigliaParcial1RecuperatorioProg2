/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1recu;

/**
 *
 * @author marti
 */
public class RobotDuplicadoException extends Exception {
    
    public RobotDuplicadoException(String mensaje) {
        super(mensaje);
    }
    
    public RobotDuplicadoException() {
        super("El robot ya esta en el sistema");
    }
}
