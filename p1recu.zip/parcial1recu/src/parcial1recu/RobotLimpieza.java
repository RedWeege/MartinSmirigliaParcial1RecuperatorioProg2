
package parcial1recu;

public class RobotLimpieza extends Robot implements Ejecutable{
    private int superficie;
    public static final int MODIFICADOR_CONSUMO_1 = 10;
    public static final int MODIFICADOR_CONSUMO_2 = 5;
    
    public RobotLimpieza(String s, String f, Prioridad p, int bateria, int superficie) {
        super(s, f, p, bateria);
        if (superficie < super.ATRIBUTO_MIN) {
            throw new IllegalArgumentException();
        }
        this.superficie = superficie;
        setConsumo(calcularConsumo());
    }
    
    @Override
    protected int calcularConsumo() {
        return this.superficie / MODIFICADOR_CONSUMO_1 + MODIFICADOR_CONSUMO_2;
    }
    @Override
    public void ejecutar() {
        if (consumirBateria()) {
            System.out.println("Servicio de Limpieza " + this.getSerie() + " ejecutado. Bateria restante: " + this.getBateria() + "%");
        }
    }
    
    public int getSuperficie() {
        return this.superficie;
    }
    
    @Override
    public String toString() {
        return this.getClass() + " [serie=" + this.getSerie() + ", fabricante=" + this.getFabricante() +", prioridad=" + this.getPrioridad() +", bateria=" +this.getBateria()+", superficie=" + this.getSuperficie() + "]";
    }
    

}
