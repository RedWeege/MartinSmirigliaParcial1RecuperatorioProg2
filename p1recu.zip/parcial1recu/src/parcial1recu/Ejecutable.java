
package parcial1recu;

public interface Ejecutable {
    
    public void ejecutar();
}
