
package parcial1recu;

public class RobotVigilancia extends Robot implements Diagnosticable {
    private int camaras;
    public static final int MODIFICADOR_CONSUMO_1 = 4;
    public static final int MODIFICADOR_CONSUMO_2 = 6;
    
    public RobotVigilancia(String s, String f, Prioridad p, int bateria, int camaras) {
        super(s, f, p, bateria);
        if (camaras < super.ATRIBUTO_MIN) {
            throw new IllegalArgumentException();
        }
        this.camaras = camaras;
        setConsumo(calcularConsumo());
    }
    @Override
    protected int calcularConsumo() {
        return this.camaras * MODIFICADOR_CONSUMO_1 + MODIFICADOR_CONSUMO_2;
    }
        
    @Override
    public void diagnosticar() {
        System.out.println("Robot de Vigilancia " + this.getSerie() + ". Cantidad de camaras: " + this.camaras);
    }
    
    public int getCamaras() {
        return this.camaras;
    }
    
    public String toString() {
        return this.getClass() + " [serie=" + this.getSerie() + ", fabricante=" + this.getFabricante() +", prioridad=" + this.getPrioridad() +", bateria=" +this.getBateria()+", camaras=" + this.getCamaras() + "]";
    }
}
