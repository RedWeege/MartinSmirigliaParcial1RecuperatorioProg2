
package parcial1recu;

import java.util.List;

public class Parcial1recu {


public static void main(String[] args) {
    FlotaRobots flota = new FlotaRobots("TecnoAsistencia");
    flota.agregarRobot(new RobotLimpieza("RL-10", "Nova", Prioridad.ALTA, 60, 80));
    flota.agregarRobot(new RobotVigilancia("RV-20", "Orbis", Prioridad.MEDIA, 75, 3));
    flota.agregarRobot(new RobotReparto("RR-30", "Nova", Prioridad.BAJA, 40, 5));
    flota.agregarRobot(new RobotReparto("RR-40", "Orbis", Prioridad.ALTA, 15, 4));
    flota.agregarRobot(new RobotVigilancia("RL-10", "Nova", Prioridad.BAJA, 90, 2));
    System.out.println("Robots registrados:");
    mostrarRobots(flota.obtenerRobots());
    System.out.println("\nEjecución de servicios:");
    ejecutarServicios(flota.obtenerRobots());
    System.out.println("\nDiagnósticos:");
    generarDiagnosticos(flota.obtenerRobots());
    System.out.println("\nRobots de prioridad ALTA:");
    mostrarRobots(flota.filtrarPorPrioridad(Prioridad.ALTA));
    System.out.println("\nRobots con consumo máximo de 18:");
    mostrarRobots(flota.filtrarPorConsumo(18));
    System.out.println("\nConsumos actuales:");
    mostrarConsumos(flota.obtenerRobots());
}
    private static void mostrarRobots(List<Robot> robots) {
    for (int i = 0 ; i < robots.size() ; i++) {
        System.out.println(robots.get(i));
    }
}
    private static void ejecutarServicios(List<Robot> robots) {
    for (int i = 0 ; i < robots.size() ; i++) {
        if (robots.get(i) instanceof Ejecutable e) {
            e.ejecutar();
        }
    }
}
    private static void generarDiagnosticos(List<Robot> robots) {
    for (int i = 0 ; i < robots.size() ; i++) {
        if (robots.get(i) instanceof Diagnosticable d) {
            d.diagnosticar();
        }
    }
}
    private static void mostrarConsumos(List<Robot> robots) {
        for (int i = 0 ; i < robots.size() ; i++) {
            System.out.println(robots.get(i).getSerie() +": " + robots.get(i).getConsumo() + " puntos de bateria por operacion.");
        }
}
}
